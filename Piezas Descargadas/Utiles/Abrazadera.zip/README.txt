                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1657541
Monster Mouth Headphone Holder - Clampable by philbarrenger is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

Headphone holder for attaching to a desk or shelf. It's a variation on my original design:
http://www.thingiverse.com/thing:1644192 
but with a screw in clamp that allows you to adjust to a shelf with a max depth of 45mm.


15 Dec 2016 - added a version with a shorter stem to suit smaller printers and headphones with a narrower head band. Inspired by @xenomorphdelombre remix. Also sports additional 3.5mm and 7mm holes for male headphone plugs on the neck given that the original holes would be covered by your headphones in this version.

11 Jan 2017 - Added a stl with a 20mm shorter stem so there's not so much wastage with thicker desks.

11 Jan 2017 - Added a version with a 30mm extension to the depth of the clamp section to better support desks with a large beveled edge. NOTE - experimental, I haven't personally printed this one yet.



# Print Settings

Printer: wanhao duplicator v2
Resolution: 0.2
Infill: 10 to 20