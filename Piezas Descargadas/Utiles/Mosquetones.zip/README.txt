                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1008943
*NEW* Strong Flex door Carabiner ddf3d Customized by Charlie1982 is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

So glad to share the design to you  
*NEW* Strong Flex door Carabiner  

Check out new ORIGAMI Carabiner ! (thing:1819242)
-------------------------------------------------
It's a long process to make the previous design as perfect as it should be, and now the core design feature was mature enough to face on the new usability challenge.  

The new design come with only 2 parts, hook and door, very easy to assembly and easy to make different scale for your need.  

Scaled capacity of 75% to 120%

Door Flexible Strength = 3 (check out the selflex introduce on http://www.ddf3d.com/)

Check out the assembly film here:   
https://www.youtube.com/watch?v=7wZM2DuAc4U  

Check out the printable operation film here:  
https://www.youtube.com/watch?v=tjnVmANtvWk  

Check out more cool design on  
http://www.ddf3d.com/  

Design for general FDM 3D printer print by PLA or ABS material.  
No additional support need, easy to print.  
Fast print design make general print time around 45-100 min.  

When print on scale 1, infill 50%, nozzle 0.4mm, shell loop 3, general can load 15-35kg load.  
The design can print without support and raft set.  
Layer high from 0.15mm~0.3mm is fine.  
Infill better to use over 50%.  

Hope you will like it ;)  







# Print Settings

Rafts: Doesn't Matter
Supports: No
Resolution: 0.15mm
Infill: 50%

Notes: 
ABS is better than PLA on tensile load and flexible spring strength.
When print on scale 1, infill 50%, nozzle 0.4mm, shell loop 3, general can load 15-35kg load.  
The design can print without support and raft set.  
Layer high from 0.15mm~0.3mm is fine.  
Infill better to use over 50%.  

Hope you will like it ;)  

# How I Designed This

<iframe src="//www.youtube.com/embed/QsJYL46oCqQ" frameborder="0" allowfullscreen></iframe>

<iframe src="//www.youtube.com/embed/-GuSk6V4ZcY" frameborder="0" allowfullscreen></iframe>

Check out more cool design on  
http://www.ddf3d.com/  

# Special Reward to Supporter

![Alt text](https://cdn.thingiverse.com/assets/51/8b/ee/1d/35/_DSC00927_TG_S.jpg)

Special Reward to Supporter
-------------------------------------------------
TIP us $5 and reward the "Classic Lock Carabiner" 3d printable file.
**We welcome your support by simple Tip to us, and we'll reward the "Classic Lock Carabiner" 3d printable file to you.**
If you are going to Tip us and get reward, please follow the step.
1) Tip us on Thingiverse $5 or more.
2) Send us a message on "ddf3d.com" contact, tell us your mail and thingiverse ID.
3) Receive the mail attachment the reward 3d file.
Please Note: Please understand, we will send the file manualy ASAP, if you don't receive the mail in 12hrs, please contact us again. Thank you

<iframe src="//www.youtube.com/embed/W4e2gUbTutk" frameborder="0" allowfullscreen></iframe>

<iframe src="//www.youtube.com/embed/L2Kzo_WZv-g" frameborder="0" allowfullscreen></iframe>