                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1196989
USB Flash Drive Cryptex v2 by Freakazoid is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Make your USB stick physically safe by printing a combination lock for it. The NSA won't stand a chance!

This is the second Version of the Flash Drive Cryptex: http://www.thingiverse.com/thing:184911

The original is made for an INTENSO RAINBOW LINE flash drive with a 40x15.8x4 mm.  cavity for the circuit.

*******************************************************************
EDIT 1:
For KINGSTON DT flash drive check out this link:
http://www.thingiverse.com/thing:1608071 

*******************************************************************

EDIT 2:
CarryTheWhat made an awesome assembly video:
https://www.youtube.com/watch?v=1PKbwCBFtak

*******************************************************************

EDIT 3: 
I added Customizer for the FLASH DRIVE CASE:
http://www.thingiverse.com/thing:1740723

# Print Settings

Printer Brand: RepRap
Printer: Prusa Mendel i3
Rafts: Doesn't Matter
Supports: Doesn't Matter

Notes: 
Print: Case_Top, Case_Bottom, Cover, Jacket and 4 rings of your choosing. I printed the design both on a Reprap i3 and a professional SLS printer. Both turned out great.

# Post-Printing

## Flash drive case

Print both case shells, clean them up and glue them together with the flash drive circuit inside. The design is fitted for an INTENSO RAINBOW LINE drive I had laying around. If you are using a different drive, you may have to do some carving.Spacing for the circuit board is 40 x 15.8 x 4 mm. 
Make sure the shells fit nicely. I used a paper binder clip to squeeze the halves together. After the glue is dry, smooth the edges and remove residues of the glue. 

## Cryptex

Slide the four Rings you chose onto the jacket. Make sure the orientation of the rings is right (compare to the picture). Add fill some glue into the notch inside of the cover and snap the jacket onto is. If it dies not fit, twist the parts around untiil they snap together. the is a little fitting key inside the notch to maintain the right orientation of the parts.

<iframe src="//www.youtube.com/embed/1PKbwCBFtak" frameborder="0" allowfullscreen></iframe>