                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:329596
T-Rex Shower Head by JMSchwartz11 is licensed under the Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

**3D print your own at:   
https://www.voodoomfg.com/ **

Now available for purchase at:   
https://www.etsy.com/listing/242077020/t-rex-shower-head-original-by-designer?ref=shop_home_active_1



-----  

T-Rex says "Get clean, or get eaten! Rawrrrr!"  
Will fit on any standard 1/2" shower head pipe. Buy this if you want to allow it to swivel (http://www.amazon.com/Opella-205-995-280-Shower-Swivel-Nickel/dp/B0038FLVRK). Use teflon tape for a good seal between the pipe and the head.   
The V2 file has a more spread stream.   
  
As seen on:   
-http://gizmodo.com/t-rex-skull-shower-heads-justify-the-existence-of-3d-pr-1651265059   
-http://www.cnet.com/news/3d-printed-t-rex-roars-water-onto-your-body/  
-http://boingboing.net/2014/11/12/3d-printed-t-rex-shower-head.html   


# Instructions

Print on a raft with no supports. I used 50% infill to prevent leaking. 2 shells. Any resolution. PLA or ABS should work fine.   
Will fit on any standard 1/2" shower head pipe. Buy this if you want to allow it to swivel (http://www.amazon.com/Opella-205-995-280-Shower-Swivel-Nickel/dp/B0038FLVRK). Use teflon tape for a good seal between the pipe and the head.   
The V2 file has a more spread stream.