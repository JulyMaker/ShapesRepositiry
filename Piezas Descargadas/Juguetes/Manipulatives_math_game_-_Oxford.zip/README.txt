                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3278447
Juego matemáticas manipulativas / Manipulatives math game - Oxford by Sacr3dShapes is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Remix del famoso juego de matemáticas manipulativas Numicon de la Universidad de Oxford. Se trata de que los niños puedan aprender a contar fácilmente, con piezas de colores que se combinan en su tablero para ver equivalencias entre unas combinaciones y otras de fichas.

En este caso he cambiado los colores para que coincidieran con otro juego análogo que son piezas de madera y así poder trabajar conjuntamente con los dos.

También quise hacer un experimento: Una impresión sobre otra, de ahí las letras en otro color en la base del juego. Estoy preparando un blog para explicar todos los procesos que sigo en mis impresiones, que están llenos de pruebas, ensayo-error, y mucha imaginación.

Si no tienes infraestructura para imprimir las piezas, puedes ponerte en contacto conmigo por mensaje privado en esta misma plataforma o a través de mi tienda online:

https://www.etsy.com/es/shop/Sacr3dShapes3Dprint

-------------------------------------------------------------------------------------------------------------------------

Remix of the famous manipulative math game Numicon from the University of Oxford. It is about that children can learn to count easily, with pieces of colors that are combined on their board to see equivalences between some combinations and others of chips.

In this case I have changed the colors so that they coincide with another analog game that are pieces of wood and thus be able to work together with the two.

I also wanted to do an experiment: One impression on another, hence the letters in another color at the base of the game. I am preparing a blog to explain all the processes that I follow in my impressions, which are full of tests, trial-error, and a lot of imagination.

If you do not have the infrastructure to print the pieces, you can contact me by private message on this platform or through my online store:

https://www.etsy.com/shop/Sacr3dShapes3Dprint