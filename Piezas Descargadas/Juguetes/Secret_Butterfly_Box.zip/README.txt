                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2977908
Secret Butterfly Box by 3DPRINTINGWORLD is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

##Secret Butterfly Box

This is a secret puzzle box. There is a secret way of opening it...  First you must find the hidden key... Then you must find the key hole... Good luck!!!

This is a remix of the original Korean Secret Box I designed. If you would like to know the history of this box or download these stl's they can be found here: https://pinshape.com/items/43755

7/22/18 -  I added a blank top and title assembly for all you butterfly haters. 
_______________________________________________________________

##Printing Instructions:
If you print in the orientations provided supports will not be required for any of the parts. I would use a brim on the key to keep it stable while printing. There are two versions of the drawer, one with a small handle and one that uses a spring. I printed all the parts out of PLA with the exception of the spring which was printed out of ABS. The spring is one shell thickness so make sure you have thin walls selected in your slicer. PETG might work for the spring as well but I have not tried it. You will also need a .4mm nozzle or smaller to print the parts with the details of the butterflies. If your nozzle width is to wide you will miss some of the details of the butterflies.

##Assembly:
After you have all the parts printed see the link below for a video containing the assembly instructions.  Besides the printed parts you will need one piece of 1.75mm filament 5 inches long, a standard pen spring, and some super glue.  The assembly is very easy just make sure you have all the parts in place before you apply the glue.

Demonstration video:
https://youtu.be/hrmvgV9LExE

Assembly video:
https://youtu.be/ze1X3e2B44o



# Print Settings

Printer Brand: Prusa
Printer: i3 MK3
Rafts: No
Supports: No