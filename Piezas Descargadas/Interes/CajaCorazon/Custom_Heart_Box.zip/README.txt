                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1221494
Custom Heart Box by emmett is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

This is an update to my Preassembled Secret Heart Box, which is smaller and much sturdier. I redesigned the latching mechanism so that it holds much more securely and doesn't wear out. I also designed this so you could easily put two initials on the box using Customizer. 

I find this works quite well as an earring box or pill box, or just as a handy stocking stuffer to fill with small treats. Enjoy!

Note: this is a complex file, so Customizer's preview will time out, but if you click Create Thing, it will properly generate the object. 

# Post-Printing

This box works best when it is slightly fused coming off the print bed. I use an exacto knife to help free it up, first by opening the lid, then separate the two lid pieces, then close it and rotate once the halves are separate. If it's too fused to get moving, enlarge the tolerance slightly in Customizer and reprint.